import { useState } from 'react';
import { useRestaurant, MenuItem } from '../store/RestaurantContext';
import { QRCodeSVG } from 'qrcode.react';
import {
  LayoutDashboard, UtensilsCrossed, ClipboardList, Users, Settings, LogOut,
  Plus, Trash2, Edit, Eye, EyeOff, Clock, X, ChefHat,
  ToggleLeft, ToggleRight, QrCode, Store, DollarSign, AlertCircle
} from 'lucide-react';

interface AdminDashboardProps {
  onLogout: () => void;
}

type Tab = 'dashboard' | 'menu' | 'orders' | 'staff' | 'tables' | 'qr' | 'settings';

export default function AdminDashboard({ onLogout }: AdminDashboardProps) {
  const [activeTab, setActiveTab] = useState<Tab>('dashboard');
  const [sidebarOpen, setSidebarOpen] = useState(false);

  const tabs: { key: Tab; label: string; icon: React.ReactNode }[] = [
    { key: 'dashboard', label: 'Dashboard', icon: <LayoutDashboard size={20} /> },
    { key: 'orders', label: 'Orders', icon: <ClipboardList size={20} /> },
    { key: 'menu', label: 'Menu', icon: <UtensilsCrossed size={20} /> },
    { key: 'staff', label: 'Staff', icon: <Users size={20} /> },
    { key: 'tables', label: 'Tables', icon: <Store size={20} /> },
    { key: 'qr', label: 'QR Codes', icon: <QrCode size={20} /> },
    { key: 'settings', label: 'Settings', icon: <Settings size={20} /> },
  ];

  return (
    <div className="min-h-screen bg-gray-100 flex">
      {/* Sidebar */}
      <aside className={`fixed md:static inset-y-0 left-0 z-50 w-64 bg-gradient-to-b from-gray-900 to-gray-800 text-white transform ${sidebarOpen ? 'translate-x-0' : '-translate-x-full'} md:translate-x-0 transition-transform`}>
        <div className="p-4 border-b border-gray-700">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 bg-gradient-to-r from-orange-500 to-amber-500 rounded-xl flex items-center justify-center">
              <span className="font-bold text-lg">S</span>
            </div>
            <div>
              <h2 className="font-bold">SIXTIN Admin</h2>
              <p className="text-xs text-gray-400">Restaurant Manager</p>
            </div>
          </div>
        </div>
        <nav className="p-3 space-y-1">
          {tabs.map(tab => (
            <button
              key={tab.key}
              onClick={() => { setActiveTab(tab.key); setSidebarOpen(false); }}
              className={`w-full flex items-center gap-3 px-4 py-3 rounded-xl text-sm font-semibold transition ${activeTab === tab.key ? 'bg-orange-600 text-white' : 'text-gray-300 hover:bg-gray-700'}`}
            >
              {tab.icon}
              {tab.label}
            </button>
          ))}
        </nav>
        <div className="absolute bottom-4 left-4 right-4">
          <button onClick={onLogout} className="w-full flex items-center gap-3 px-4 py-3 rounded-xl text-sm font-semibold text-red-400 hover:bg-red-500/10 transition">
            <LogOut size={20} />
            Logout
          </button>
        </div>
      </aside>

      {/* Overlay */}
      {sidebarOpen && <div className="fixed inset-0 bg-black/50 z-40 md:hidden" onClick={() => setSidebarOpen(false)} />}

      {/* Main Content */}
      <main className="flex-1 overflow-y-auto">
        {/* Top Bar */}
        <div className="bg-white shadow-sm px-4 py-3 flex items-center justify-between sticky top-0 z-30">
          <div className="flex items-center gap-3">
            <button onClick={() => setSidebarOpen(true)} className="md:hidden p-2 hover:bg-gray-100 rounded-lg">
              <div className="flex flex-col gap-1"><span className="w-5 h-0.5 bg-gray-600"></span><span className="w-5 h-0.5 bg-gray-600"></span><span className="w-5 h-0.5 bg-gray-600"></span></div>
            </button>
            <h1 className="text-xl font-bold text-gray-800">{tabs.find(t => t.key === activeTab)?.label}</h1>
          </div>
          <div className="flex items-center gap-2">
            <a href="#/" className="text-orange-600 text-sm hover:underline font-semibold">View Site →</a>
          </div>
        </div>

        <div className="p-4 md:p-6">
          {activeTab === 'dashboard' && <DashboardTab />}
          {activeTab === 'orders' && <OrdersTab />}
          {activeTab === 'menu' && <MenuTab />}
          {activeTab === 'staff' && <StaffTab />}
          {activeTab === 'tables' && <TablesTab />}
          {activeTab === 'qr' && <QRTab />}
          {activeTab === 'settings' && <SettingsTab />}
        </div>
      </main>
    </div>
  );
}

/* ============ Dashboard Tab ============ */
function DashboardTab() {
  const { orders, isOpen, toggleOpen, tables } = useRestaurant();
  const todayOrders = orders.filter(o => new Date(o.createdAt).toDateString() === new Date().toDateString());
  const totalRevenue = todayOrders.reduce((s, o) => s + o.total, 0);
  const pendingOrders = orders.filter(o => o.status === 'pending' || o.status === 'confirmed' || o.status === 'preparing');
  const occupiedTables = tables.filter(t => t.occupied).length;

  return (
    <div className="space-y-6">
      {/* Restaurant Status */}
      <div className={`rounded-2xl p-4 flex items-center justify-between ${isOpen ? 'bg-green-50 border-2 border-green-200' : 'bg-red-50 border-2 border-red-200'}`}>
        <div className="flex items-center gap-3">
          <Store size={24} className={isOpen ? 'text-green-600' : 'text-red-600'} />
          <div>
            <h3 className="font-bold text-lg">{isOpen ? '🟢 Restaurant is OPEN' : '🔴 Restaurant is CLOSED'}</h3>
            <p className="text-sm text-gray-500">Click to change status</p>
          </div>
        </div>
        <button onClick={toggleOpen} className={`px-6 py-2 rounded-xl font-bold text-white transition ${isOpen ? 'bg-red-500 hover:bg-red-600' : 'bg-green-500 hover:bg-green-600'}`}>
          {isOpen ? 'Close Restaurant' : 'Open Restaurant'}
        </button>
      </div>

      {/* Stats */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        <StatCard icon={<ClipboardList className="text-orange-500" />} label="Today's Orders" value={todayOrders.length.toString()} bg="bg-orange-50" />
        <StatCard icon={<DollarSign className="text-green-500" />} label="Today's Revenue" value={`₹${totalRevenue}`} bg="bg-green-50" />
        <StatCard icon={<AlertCircle className="text-yellow-500" />} label="Pending Orders" value={pendingOrders.length.toString()} bg="bg-yellow-50" />
        <StatCard icon={<Store className="text-blue-500" />} label="Occupied Tables" value={`${occupiedTables}/7`} bg="bg-blue-50" />
      </div>

      {/* Recent Orders */}
      <div className="bg-white rounded-2xl shadow-md p-4">
        <h3 className="font-bold text-lg mb-4">📋 Recent Orders</h3>
        {orders.length === 0 ? (
          <p className="text-gray-400 text-center py-8">No orders yet</p>
        ) : (
          <div className="space-y-2 max-h-96 overflow-y-auto">
            {orders.slice(0, 10).map(order => (
              <div key={order.orderId} className="flex items-center justify-between p-3 bg-gray-50 rounded-xl">
                <div>
                  <span className="font-bold text-orange-600">#{order.orderId}</span>
                  <span className="text-sm text-gray-500 ml-2">{order.customerName}</span>
                  <span className="text-sm text-gray-400 ml-2">Table {order.tableNo}</span>
                </div>
                <div className="flex items-center gap-2">
                  <span className="font-bold">₹{order.total}</span>
                  <StatusBadge status={order.status} />
                </div>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}

function StatCard({ icon, label, value, bg }: { icon: React.ReactNode; label: string; value: string; bg: string }) {
  return (
    <div className={`${bg} rounded-2xl p-4 flex items-center gap-4`}>
      <div className="p-3 bg-white rounded-xl shadow-sm">{icon}</div>
      <div>
        <p className="text-2xl font-bold text-gray-800">{value}</p>
        <p className="text-sm text-gray-500">{label}</p>
      </div>
    </div>
  );
}

function StatusBadge({ status }: { status: string }) {
  const colors: Record<string, string> = {
    pending: 'bg-yellow-100 text-yellow-700',
    confirmed: 'bg-blue-100 text-blue-700',
    preparing: 'bg-purple-100 text-purple-700',
    ready: 'bg-green-100 text-green-700',
    delivered: 'bg-gray-100 text-gray-700',
    cancelled: 'bg-red-100 text-red-700',
  };
  return (
    <span className={`px-2 py-1 rounded-full text-xs font-semibold ${colors[status] || 'bg-gray-100 text-gray-600'}`}>
      {status}
    </span>
  );
}

/* ============ Orders Tab ============ */
function OrdersTab() {
  const { orders, updateOrderStatus, updatePaymentStatus, setEstimatedTime } = useRestaurant();
  const [filter, setFilter] = useState('all');
  const [timeInput, setTimeInput] = useState<Record<number, string>>({});

  const filtered = filter === 'all' ? orders : orders.filter(o => o.status === filter);

  return (
    <div className="space-y-4">
      <div className="flex gap-2 overflow-x-auto pb-2">
        {['all', 'pending', 'confirmed', 'preparing', 'ready', 'delivered', 'cancelled'].map(f => (
          <button
            key={f}
            onClick={() => setFilter(f)}
            className={`px-4 py-2 rounded-xl text-sm font-semibold whitespace-nowrap transition ${filter === f ? 'bg-orange-600 text-white' : 'bg-white text-gray-600 hover:bg-orange-100'}`}
          >
            {f.charAt(0).toUpperCase() + f.slice(1)}
            {f !== 'all' && <span className="ml-1 text-xs">({orders.filter(o => o.status === f).length})</span>}
          </button>
        ))}
      </div>

      {filtered.length === 0 ? (
        <div className="text-center py-12 text-gray-400 bg-white rounded-2xl">
          <ClipboardList size={48} className="mx-auto mb-4 opacity-50" />
          <p>No orders found</p>
        </div>
      ) : (
        <div className="space-y-4">
          {filtered.map(order => (
            <div key={order.orderId} className="bg-white rounded-2xl shadow-md p-4">
              <div className="flex items-center justify-between mb-3 flex-wrap gap-2">
                <div className="flex items-center gap-3">
                  <span className="text-xl font-bold text-orange-600">#{order.orderId}</span>
                  <StatusBadge status={order.status} />
                  <span className={`px-2 py-1 rounded-full text-xs font-semibold ${order.paymentStatus === 'paid' ? 'bg-green-100 text-green-700' : 'bg-yellow-100 text-yellow-700'}`}>
                    💰 {order.paymentStatus}
                  </span>
                </div>
                <span className="text-sm text-gray-400">{new Date(order.createdAt).toLocaleString()}</span>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-3">
                <div className="bg-gray-50 rounded-xl p-3">
                  <p className="text-sm"><strong>👤 Customer:</strong> {order.customerName}</p>
                  <p className="text-sm"><strong>📱 Phone:</strong> {order.customerPhone}</p>
                  <p className="text-sm"><strong>🪑 Table:</strong> {order.tableNo}</p>
                  <p className="text-sm"><strong>💳 Payment:</strong> {order.paymentMethod.toUpperCase()}</p>
                  {order.estimatedTime && (
                    <p className="text-sm text-orange-600 font-semibold"><strong>⏰ ETA:</strong> {order.estimatedTime} min</p>
                  )}
                </div>
                <div className="bg-gray-50 rounded-xl p-3">
                  <p className="text-sm font-semibold mb-2">📋 Items:</p>
                  {order.items.map((item, i) => (
                    <p key={i} className="text-sm text-gray-600">{item.item.name} × {item.quantity} = ₹{item.item.price * item.quantity}</p>
                  ))}
                  <p className="text-sm font-bold mt-2 text-orange-600">Total: ₹{order.total}</p>
                </div>
              </div>

              {/* Estimated Time */}
              <div className="flex items-center gap-2 mb-3 flex-wrap">
                <Clock size={16} className="text-orange-600" />
                <input
                  type="number"
                  placeholder="Mins"
                  value={timeInput[order.orderId] || ''}
                  onChange={e => setTimeInput(p => ({ ...p, [order.orderId]: e.target.value }))}
                  className="w-20 px-2 py-1 border rounded-lg text-sm"
                />
                <button
                  onClick={() => {
                    const t = parseInt(timeInput[order.orderId] || '0');
                    if (t > 0) setEstimatedTime(order.orderId, t);
                  }}
                  className="bg-orange-100 text-orange-600 px-3 py-1 rounded-lg text-sm font-semibold hover:bg-orange-200 transition"
                >
                  Set Time
                </button>
                {[10, 20, 30, 45].map(t => (
                  <button
                    key={t}
                    onClick={() => setEstimatedTime(order.orderId, t)}
                    className="bg-gray-100 text-gray-600 px-2 py-1 rounded-lg text-xs font-semibold hover:bg-orange-100 transition"
                  >
                    {t}m
                  </button>
                ))}
              </div>

              {/* Status Actions */}
              <div className="flex flex-wrap gap-2">
                {order.status !== 'confirmed' && order.status !== 'cancelled' && order.status !== 'delivered' && (
                  <button onClick={() => updateOrderStatus(order.orderId, 'confirmed')} className="bg-blue-500 text-white px-3 py-2 rounded-xl text-xs font-semibold hover:bg-blue-600 transition">
                    ✅ Confirm
                  </button>
                )}
                {order.status !== 'preparing' && order.status !== 'cancelled' && order.status !== 'delivered' && (
                  <button onClick={() => updateOrderStatus(order.orderId, 'preparing')} className="bg-purple-500 text-white px-3 py-2 rounded-xl text-xs font-semibold hover:bg-purple-600 transition">
                    👨‍🍳 Preparing
                  </button>
                )}
                {order.status !== 'ready' && order.status !== 'cancelled' && order.status !== 'delivered' && (
                  <button onClick={() => updateOrderStatus(order.orderId, 'ready')} className="bg-green-500 text-white px-3 py-2 rounded-xl text-xs font-semibold hover:bg-green-600 transition">
                    🍽️ Ready
                  </button>
                )}
                {order.status !== 'delivered' && order.status !== 'cancelled' && (
                  <button onClick={() => updateOrderStatus(order.orderId, 'delivered')} className="bg-gray-600 text-white px-3 py-2 rounded-xl text-xs font-semibold hover:bg-gray-700 transition">
                    📦 Delivered
                  </button>
                )}
                {order.status !== 'cancelled' && order.status !== 'delivered' && (
                  <button onClick={() => updateOrderStatus(order.orderId, 'cancelled')} className="bg-red-500 text-white px-3 py-2 rounded-xl text-xs font-semibold hover:bg-red-600 transition">
                    ❌ Cancel
                  </button>
                )}
                {order.paymentStatus === 'pending' && (
                  <button onClick={() => updatePaymentStatus(order.orderId, 'paid')} className="bg-emerald-500 text-white px-3 py-2 rounded-xl text-xs font-semibold hover:bg-emerald-600 transition">
                    💰 Mark Paid
                  </button>
                )}
                {order.paymentStatus === 'paid' && (
                  <span className="bg-green-100 text-green-700 px-3 py-2 rounded-xl text-xs font-semibold">✅ Paid</span>
                )}
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}

/* ============ Menu Tab ============ */
function MenuTab() {
  const { menuItems, addMenuItem, updateMenuItem, removeMenuItem, toggleItemAvailability, categories, addCategory, removeCategory } = useRestaurant();
  const [showForm, setShowForm] = useState(false);
  const [editId, setEditId] = useState<string | null>(null);
  const [form, setForm] = useState<Partial<MenuItem>>({ name: '', price: 0, category: '', image: '', description: '', veg: true, available: true });
  const [newCategory, setNewCategory] = useState('');

  const handleSubmit = () => {
    if (!form.name || !form.price || !form.category) return;
    if (editId) {
      updateMenuItem(editId, form);
      setEditId(null);
    } else {
      addMenuItem({ ...form, id: Date.now().toString() } as MenuItem);
    }
    setForm({ name: '', price: 0, category: '', image: '', description: '', veg: true, available: true });
    setShowForm(false);
  };

  const startEdit = (item: MenuItem) => {
    setForm(item);
    setEditId(item.id);
    setShowForm(true);
  };

  return (
    <div className="space-y-4">
      {/* Categories Manager */}
      <div className="bg-white rounded-2xl shadow-md p-4">
        <h3 className="font-bold text-lg mb-3">📂 Categories</h3>
        <div className="flex flex-wrap gap-2 mb-3">
          {categories.map(cat => (
            <span key={cat} className="bg-orange-100 text-orange-700 px-3 py-1 rounded-full text-sm flex items-center gap-2">
              {cat}
              <button onClick={() => removeCategory(cat)} className="text-red-400 hover:text-red-600"><X size={14} /></button>
            </span>
          ))}
        </div>
        <div className="flex gap-2">
          <input
            type="text"
            value={newCategory}
            onChange={e => setNewCategory(e.target.value)}
            placeholder="New category name"
            className="flex-1 px-3 py-2 border rounded-lg text-sm"
          />
          <button onClick={() => { if (newCategory.trim()) { addCategory(newCategory.trim()); setNewCategory(''); } }} className="bg-orange-600 text-white px-4 py-2 rounded-lg text-sm font-semibold">
            + Add
          </button>
        </div>
      </div>

      {/* Add/Edit Menu Item */}
      <div className="flex justify-between items-center">
        <h3 className="font-bold text-lg">🍽️ Menu Items ({menuItems.length})</h3>
        <button onClick={() => { setShowForm(!showForm); setEditId(null); setForm({ name: '', price: 0, category: '', image: '', description: '', veg: true, available: true }); }} className="bg-orange-600 text-white px-4 py-2 rounded-xl text-sm font-semibold flex items-center gap-1">
          <Plus size={16} /> Add Item
        </button>
      </div>

      {showForm && (
        <div className="bg-white rounded-2xl shadow-md p-4 space-y-3">
          <h3 className="font-bold">{editId ? 'Edit Item' : 'Add New Item'}</h3>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
            <input
              type="text" placeholder="Item Name"
              value={form.name}
              onChange={e => setForm(p => ({ ...p, name: e.target.value }))}
              className="px-3 py-2 border rounded-lg text-sm"
            />
            <input
              type="number" placeholder="Price (₹)"
              value={form.price || ''}
              onChange={e => setForm(p => ({ ...p, price: parseInt(e.target.value) || 0 }))}
              className="px-3 py-2 border rounded-lg text-sm"
            />
            <select
              value={form.category}
              onChange={e => setForm(p => ({ ...p, category: e.target.value }))}
              className="px-3 py-2 border rounded-lg text-sm"
            >
              <option value="">Select Category</option>
              {categories.map(cat => <option key={cat} value={cat}>{cat}</option>)}
            </select>
            <input
              type="text" placeholder="Image URL"
              value={form.image}
              onChange={e => setForm(p => ({ ...p, image: e.target.value }))}
              className="px-3 py-2 border rounded-lg text-sm"
            />
            <textarea
              placeholder="Description"
              value={form.description}
              onChange={e => setForm(p => ({ ...p, description: e.target.value }))}
              className="px-3 py-2 border rounded-lg text-sm md:col-span-2"
            />
          </div>
          <div className="flex items-center gap-4">
            <label className="flex items-center gap-2 text-sm">
              <input type="checkbox" checked={form.veg} onChange={e => setForm(p => ({ ...p, veg: e.target.checked }))} className="accent-green-500" />
              Vegetarian
            </label>
            <label className="flex items-center gap-2 text-sm">
              <input type="checkbox" checked={form.available} onChange={e => setForm(p => ({ ...p, available: e.target.checked }))} className="accent-orange-500" />
              Available
            </label>
          </div>
          <div className="flex gap-2">
            <button onClick={handleSubmit} className="bg-orange-600 text-white px-6 py-2 rounded-xl text-sm font-semibold">
              {editId ? '✏️ Update' : '➕ Add Item'}
            </button>
            <button onClick={() => { setShowForm(false); setEditId(null); }} className="bg-gray-200 text-gray-600 px-6 py-2 rounded-xl text-sm font-semibold">
              Cancel
            </button>
          </div>
        </div>
      )}

      {/* Menu Items List */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
        {menuItems.map(item => (
          <div key={item.id} className={`bg-white rounded-2xl shadow-md p-3 flex gap-3 ${!item.available ? 'opacity-60' : ''}`}>
            <img src={item.image} alt={item.name} className="w-20 h-20 rounded-xl object-cover"
              onError={(e) => { (e.target as HTMLImageElement).src = 'https://images.unsplash.com/photo-1546069901-ba9599a7e63c?w=200'; }} />
            <div className="flex-1">
              <div className="flex items-center gap-2">
                <h4 className="font-bold text-sm">{item.name}</h4>
                {item.veg ? <span className="text-green-500 text-xs">🟢 Veg</span> : <span className="text-red-500 text-xs">🔴 Non-Veg</span>}
              </div>
              <p className="text-orange-600 font-bold text-sm">₹{item.price}</p>
              <p className="text-xs text-gray-400">{item.category}</p>
            </div>
            <div className="flex flex-col gap-1">
              <button onClick={() => toggleItemAvailability(item.id)} className={`p-1.5 rounded-lg text-xs ${item.available ? 'bg-green-100 text-green-600' : 'bg-red-100 text-red-600'}`}>
                {item.available ? <Eye size={14} /> : <EyeOff size={14} />}
              </button>
              <button onClick={() => startEdit(item)} className="p-1.5 bg-blue-100 text-blue-600 rounded-lg"><Edit size={14} /></button>
              <button onClick={() => removeMenuItem(item.id)} className="p-1.5 bg-red-100 text-red-600 rounded-lg"><Trash2 size={14} /></button>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}

/* ============ Staff Tab ============ */
function StaffTab() {
  const { staff, addStaff, removeStaff, toggleStaffActive } = useRestaurant();
  const [showForm, setShowForm] = useState(false);
  const [form, setForm] = useState({ name: '', role: '', phone: '' });

  const handleAdd = () => {
    if (!form.name || !form.role) return;
    addStaff({ id: Date.now().toString(), ...form, active: true });
    setForm({ name: '', role: '', phone: '' });
    setShowForm(false);
  };

  return (
    <div className="space-y-4">
      <div className="flex justify-between items-center">
        <h3 className="font-bold text-lg">👨‍🍳 Staff Members ({staff.length})</h3>
        <button onClick={() => setShowForm(!showForm)} className="bg-orange-600 text-white px-4 py-2 rounded-xl text-sm font-semibold flex items-center gap-1">
          <Plus size={16} /> Add Staff
        </button>
      </div>

      {showForm && (
        <div className="bg-white rounded-2xl shadow-md p-4 space-y-3">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
            <input type="text" placeholder="Name" value={form.name} onChange={e => setForm(p => ({ ...p, name: e.target.value }))} className="px-3 py-2 border rounded-lg text-sm" />
            <input type="text" placeholder="Role (Chef, Waiter, etc.)" value={form.role} onChange={e => setForm(p => ({ ...p, role: e.target.value }))} className="px-3 py-2 border rounded-lg text-sm" />
            <input type="text" placeholder="Phone" value={form.phone} onChange={e => setForm(p => ({ ...p, phone: e.target.value }))} className="px-3 py-2 border rounded-lg text-sm" />
          </div>
          <button onClick={handleAdd} className="bg-orange-600 text-white px-6 py-2 rounded-xl text-sm font-semibold">Add Staff</button>
        </div>
      )}

      {staff.length === 0 ? (
        <div className="bg-white rounded-2xl shadow-md p-8 text-center text-gray-400">
          <Users size={48} className="mx-auto mb-4 opacity-50" />
          <p>No staff members added yet</p>
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
          {staff.map(s => (
            <div key={s.id} className={`bg-white rounded-2xl shadow-md p-4 flex items-center gap-4 ${!s.active ? 'opacity-60' : ''}`}>
              <div className="w-12 h-12 bg-orange-100 rounded-full flex items-center justify-center">
                <ChefHat className="text-orange-600" size={24} />
              </div>
              <div className="flex-1">
                <h4 className="font-bold">{s.name}</h4>
                <p className="text-sm text-gray-500">{s.role}</p>
                <p className="text-xs text-gray-400">{s.phone}</p>
              </div>
              <div className="flex items-center gap-2">
                <button onClick={() => toggleStaffActive(s.id)} className={`p-2 rounded-lg ${s.active ? 'text-green-600' : 'text-gray-400'}`}>
                  {s.active ? <ToggleRight size={24} /> : <ToggleLeft size={24} />}
                </button>
                <button onClick={() => removeStaff(s.id)} className="p-2 text-red-400 hover:text-red-600"><Trash2 size={18} /></button>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}

/* ============ Tables Tab ============ */
function TablesTab() {
  const { tables, toggleTableOccupied, orders } = useRestaurant();

  return (
    <div className="space-y-4">
      <h3 className="font-bold text-lg">🪑 Table Management</h3>
      <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 gap-4">
        {tables.map(table => {
          const tableOrders = orders.filter(o => o.tableNo === table.no && (o.status === 'pending' || o.status === 'confirmed' || o.status === 'preparing' || o.status === 'ready'));
          return (
            <div
              key={table.no}
              className={`rounded-2xl p-6 text-center cursor-pointer transition hover:shadow-lg ${table.occupied ? 'bg-red-100 border-2 border-red-300' : 'bg-green-100 border-2 border-green-300'}`}
              onClick={() => toggleTableOccupied(table.no)}
            >
              <div className="text-4xl mb-2">🪑</div>
              <h4 className="text-2xl font-bold">Table {table.no}</h4>
              <p className={`text-sm font-semibold mt-1 ${table.occupied ? 'text-red-600' : 'text-green-600'}`}>
                {table.occupied ? '🔴 Occupied' : '🟢 Available'}
              </p>
              {tableOrders.length > 0 && (
                <p className="text-xs text-orange-600 mt-1">{tableOrders.length} active order(s)</p>
              )}
            </div>
          );
        })}
      </div>
    </div>
  );
}

/* ============ QR Tab ============ */
function QRTab() {
  const { tables } = useRestaurant();
  const baseUrl = window.location.origin + window.location.pathname;

  return (
    <div className="space-y-4">
      <h3 className="font-bold text-lg">📱 QR Codes for Tables</h3>
      <p className="text-gray-500 text-sm">Print these QR codes and place them on each table. Customers can scan to order directly.</p>
      <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4">
        {tables.map(table => (
          <div key={table.no} className="bg-white rounded-2xl shadow-md p-6 text-center">
            <h4 className="text-lg font-bold text-orange-600 mb-1">SIXTIN Restaurant</h4>
            <p className="text-sm text-gray-500 mb-3">Scan to Order</p>
            <div className="flex justify-center mb-3">
              <QRCodeSVG
                value={`${baseUrl}?table=${table.no}`}
                size={160}
                bgColor="white"
                fgColor="#ea580c"
                level="H"
              />
            </div>
            <div className="bg-orange-600 text-white rounded-xl py-2 px-4 font-bold text-lg">
              Table No. {table.no}
            </div>
            <p className="text-xs text-gray-400 mt-2">QR के ऊपर लिखा है Table No.</p>
          </div>
        ))}
      </div>
    </div>
  );
}

/* ============ Settings Tab ============ */
function SettingsTab() {
  const { restaurantName, setRestaurantName, whatsappNumber, setWhatsappNumber, isOpen, setIsOpen } = useRestaurant();
  const [name, setName] = useState(restaurantName);
  const [whatsapp, setWhatsapp] = useState(whatsappNumber);

  return (
    <div className="space-y-4 max-w-2xl">
      <div className="bg-white rounded-2xl shadow-md p-6 space-y-4">
        <h3 className="font-bold text-lg">⚙️ Restaurant Settings</h3>

        <div>
          <label className="block text-sm font-semibold text-gray-700 mb-1">Restaurant Name</label>
          <div className="flex gap-2">
            <input
              type="text" value={name} onChange={e => setName(e.target.value)}
              className="flex-1 px-3 py-2 border rounded-lg text-sm"
            />
            <button onClick={() => setRestaurantName(name)} className="bg-orange-600 text-white px-4 py-2 rounded-lg text-sm font-semibold">Save</button>
          </div>
        </div>

        <div>
          <label className="block text-sm font-semibold text-gray-700 mb-1">WhatsApp Number (with country code)</label>
          <div className="flex gap-2">
            <input
              type="text" value={whatsapp} onChange={e => setWhatsapp(e.target.value)}
              placeholder="919999999999"
              className="flex-1 px-3 py-2 border rounded-lg text-sm"
            />
            <button onClick={() => setWhatsappNumber(whatsapp)} className="bg-orange-600 text-white px-4 py-2 rounded-lg text-sm font-semibold">Save</button>
          </div>
          <p className="text-xs text-gray-400 mt-1">Format: 91XXXXXXXXXX (India)</p>
        </div>

        <div>
          <label className="block text-sm font-semibold text-gray-700 mb-1">Restaurant Status</label>
          <button
            onClick={() => setIsOpen(!isOpen)}
            className={`px-6 py-3 rounded-xl font-bold text-white transition ${isOpen ? 'bg-green-500 hover:bg-green-600' : 'bg-red-500 hover:bg-red-600'}`}
          >
            {isOpen ? '🟢 Open - Click to Close' : '🔴 Closed - Click to Open'}
          </button>
        </div>
      </div>

      <div className="bg-white rounded-2xl shadow-md p-6">
        <h3 className="font-bold text-lg mb-3">📌 Admin Credentials</h3>
        <div className="bg-gray-50 rounded-xl p-4 space-y-2 text-sm">
          <p><strong>Username:</strong> sixtin@owner</p>
          <p><strong>Password:</strong> owner.sixtin.@com</p>
          <p className="text-xs text-gray-400 mt-2">⚠️ Keep these credentials safe</p>
        </div>
      </div>

      <div className="bg-white rounded-2xl shadow-md p-6">
        <h3 className="font-bold text-lg mb-3">🔗 Quick Links</h3>
        <div className="space-y-2">
          <a href="#/" className="block bg-orange-50 text-orange-600 p-3 rounded-xl font-semibold hover:bg-orange-100 transition">🌐 View Customer Website</a>
          <a href="#/admin" className="block bg-gray-50 text-gray-600 p-3 rounded-xl font-semibold hover:bg-gray-100 transition">🔐 Admin Dashboard</a>
        </div>
      </div>
    </div>
  );
}
