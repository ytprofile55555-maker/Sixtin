import { useState } from 'react';
import { useRestaurant } from '../store/RestaurantContext';
import { X, Plus, Minus, Trash2, ShoppingBag, CreditCard, Banknote, Smartphone } from 'lucide-react';

interface CartDrawerProps {
  open: boolean;
  onClose: () => void;
}

export default function CartDrawer({ open, onClose }: CartDrawerProps) {
  const { cart, updateCartQuantity, removeFromCart, clearCart, getCartTotal, placeOrder, tables } = useRestaurant();
  const [step, setStep] = useState<'cart' | 'details'>('cart');
  const [customerName, setCustomerName] = useState('');
  const [customerPhone, setCustomerPhone] = useState('');
  const [tableNo, setTableNo] = useState(0);
  const [paymentMethod, setPaymentMethod] = useState<'cash' | 'upi' | 'card'>('cash');
  const [orderPlaced, setOrderPlaced] = useState(false);
  const [placedOrderId, setPlacedOrderId] = useState(0);

  const total = getCartTotal();
  const tax = Math.round(total * 0.05);
  const grandTotal = total + tax;

  const handlePlaceOrder = () => {
    if (!customerName || !customerPhone || tableNo === 0) return;
    const order = placeOrder(customerName, customerPhone, tableNo, paymentMethod);
    if (order) {
      setPlacedOrderId(order.orderId);
      setOrderPlaced(true);
    }
  };

  const handleClose = () => {
    setStep('cart');
    setOrderPlaced(false);
    setCustomerName('');
    setCustomerPhone('');
    setTableNo(0);
    onClose();
  };

  if (!open) return null;

  return (
    <div className="fixed inset-0 z-50 flex">
      <div className="absolute inset-0 bg-black/50" onClick={handleClose}></div>
      <div className="ml-auto w-full max-w-md bg-white h-full overflow-y-auto relative z-10 shadow-2xl">
        {/* Header */}
        <div className="bg-gradient-to-r from-orange-600 to-amber-500 text-white p-4 flex items-center justify-between sticky top-0 z-10">
          <div className="flex items-center gap-2">
            <ShoppingBag size={22} />
            <h2 className="text-lg font-bold">
              {orderPlaced ? 'Order Placed! 🎉' : step === 'cart' ? 'Your Cart' : 'Order Details'}
            </h2>
          </div>
          <button onClick={handleClose} className="p-1 hover:bg-white/20 rounded-full transition">
            <X size={22} />
          </button>
        </div>

        {orderPlaced ? (
          <div className="p-6 text-center">
            <div className="text-6xl mb-4 animate-bounce">✅</div>
            <h3 className="text-2xl font-bold text-green-600 mb-2">Order Placed Successfully!</h3>
            <p className="text-gray-500 mb-4">Your order #{placedOrderId} has been placed.</p>
            <div className="bg-orange-50 rounded-xl p-4 mb-4">
              <p className="text-orange-700 font-semibold">Your order will be sent to the kitchen shortly.</p>
              <p className="text-sm text-gray-500 mt-1">WhatsApp notification sent to restaurant.</p>
            </div>
            <button onClick={handleClose} className="w-full bg-orange-600 text-white py-3 rounded-xl font-bold hover:bg-orange-700 transition">
              Continue Ordering
            </button>
          </div>
        ) : step === 'cart' ? (
          <>
            {cart.length === 0 ? (
              <div className="p-8 text-center">
                <div className="text-6xl mb-4">🛒</div>
                <h3 className="text-xl font-bold text-gray-400">Your cart is empty</h3>
                <p className="text-gray-400 text-sm mt-2">Add delicious items from our menu!</p>
                <button onClick={handleClose} className="mt-4 bg-orange-600 text-white px-6 py-2 rounded-xl font-semibold hover:bg-orange-700 transition">
                  Browse Menu
                </button>
              </div>
            ) : (
              <>
                <div className="p-4 space-y-3">
                  {cart.map(cartItem => (
                    <div key={cartItem.item.id} className="bg-gray-50 rounded-xl p-3 flex items-center gap-3">
                      <img src={cartItem.item.image} alt={cartItem.item.name} className="w-16 h-16 rounded-lg object-cover"
                        onError={(e) => { (e.target as HTMLImageElement).src = 'https://images.unsplash.com/photo-1546069901-ba9599a7e63c?w=200'; }} />
                      <div className="flex-1">
                        <h4 className="font-semibold text-sm">{cartItem.item.name}</h4>
                        <p className="text-orange-600 font-bold text-sm">₹{cartItem.item.price}</p>
                      </div>
                      <div className="flex items-center gap-2">
                        <button onClick={() => updateCartQuantity(cartItem.item.id, cartItem.quantity - 1)} className="w-7 h-7 bg-orange-100 text-orange-600 rounded-full flex items-center justify-center hover:bg-orange-200 transition">
                          <Minus size={14} />
                        </button>
                        <span className="font-bold text-sm w-6 text-center">{cartItem.quantity}</span>
                        <button onClick={() => updateCartQuantity(cartItem.item.id, cartItem.quantity + 1)} className="w-7 h-7 bg-orange-600 text-white rounded-full flex items-center justify-center hover:bg-orange-700 transition">
                          <Plus size={14} />
                        </button>
                        <button onClick={() => removeFromCart(cartItem.item.id)} className="w-7 h-7 bg-red-100 text-red-500 rounded-full flex items-center justify-center hover:bg-red-200 transition ml-1">
                          <Trash2 size={14} />
                        </button>
                      </div>
                    </div>
                  ))}
                </div>

                <div className="p-4 border-t">
                  <div className="space-y-2 text-sm">
                    <div className="flex justify-between"><span className="text-gray-500">Subtotal</span><span>₹{total}</span></div>
                    <div className="flex justify-between"><span className="text-gray-500">GST (5%)</span><span>₹{tax}</span></div>
                    <div className="flex justify-between font-bold text-lg border-t pt-2"><span>Total</span><span className="text-orange-600">₹{grandTotal}</span></div>
                  </div>
                  <div className="flex gap-2 mt-4">
                    <button onClick={clearCart} className="flex-1 border-2 border-red-200 text-red-500 py-3 rounded-xl font-semibold hover:bg-red-50 transition">
                      Clear Cart
                    </button>
                    <button onClick={() => setStep('details')} className="flex-1 bg-orange-600 text-white py-3 rounded-xl font-bold hover:bg-orange-700 transition">
                      Checkout →
                    </button>
                  </div>
                </div>
              </>
            )}
          </>
        ) : (
          <div className="p-4 space-y-4">
            <button onClick={() => setStep('cart')} className="text-orange-600 text-sm font-semibold hover:underline">← Back to Cart</button>

            <div>
              <label className="block text-sm font-semibold text-gray-700 mb-1">Your Name *</label>
              <input
                type="text"
                value={customerName}
                onChange={e => setCustomerName(e.target.value)}
                placeholder="Enter your name"
                className="w-full px-4 py-3 border-2 border-gray-200 rounded-xl focus:border-orange-400 outline-none transition"
              />
            </div>

            <div>
              <label className="block text-sm font-semibold text-gray-700 mb-1">Phone Number *</label>
              <input
                type="tel"
                value={customerPhone}
                onChange={e => setCustomerPhone(e.target.value)}
                placeholder="Enter phone number"
                className="w-full px-4 py-3 border-2 border-gray-200 rounded-xl focus:border-orange-400 outline-none transition"
              />
            </div>

            <div>
              <label className="block text-sm font-semibold text-gray-700 mb-1">Table Number * <span className="text-xs text-gray-400">(QR के ऊपर लिखा है)</span></label>
              <div className="grid grid-cols-4 gap-2 mt-2">
                {tables.map(t => (
                  <button
                    key={t.no}
                    onClick={() => setTableNo(t.no)}
                    disabled={t.occupied}
                    className={`p-3 rounded-xl text-center font-bold transition ${
                      t.occupied ? 'bg-red-100 text-red-400 cursor-not-allowed' :
                      tableNo === t.no ? 'bg-orange-600 text-white shadow-lg scale-105' :
                      'bg-gray-100 text-gray-600 hover:bg-orange-100'
                    }`}
                  >
                    <div className="text-lg">{t.no}</div>
                    <div className="text-[10px]">{t.occupied ? 'Occupied' : 'Available'}</div>
                  </button>
                ))}
              </div>
            </div>

            <div>
              <label className="block text-sm font-semibold text-gray-700 mb-2">Payment Method *</label>
              <div className="grid grid-cols-3 gap-2">
                <button
                  onClick={() => setPaymentMethod('cash')}
                  className={`p-3 rounded-xl border-2 text-center transition ${paymentMethod === 'cash' ? 'border-orange-500 bg-orange-50' : 'border-gray-200 hover:border-orange-300'}`}
                >
                  <Banknote size={24} className="mx-auto mb-1 text-green-600" />
                  <span className="text-xs font-semibold">Cash</span>
                </button>
                <button
                  onClick={() => setPaymentMethod('upi')}
                  className={`p-3 rounded-xl border-2 text-center transition ${paymentMethod === 'upi' ? 'border-orange-500 bg-orange-50' : 'border-gray-200 hover:border-orange-300'}`}
                >
                  <Smartphone size={24} className="mx-auto mb-1 text-purple-600" />
                  <span className="text-xs font-semibold">UPI</span>
                </button>
                <button
                  onClick={() => setPaymentMethod('card')}
                  className={`p-3 rounded-xl border-2 text-center transition ${paymentMethod === 'card' ? 'border-orange-500 bg-orange-50' : 'border-gray-200 hover:border-orange-300'}`}
                >
                  <CreditCard size={24} className="mx-auto mb-1 text-blue-600" />
                  <span className="text-xs font-semibold">Card</span>
                </button>
              </div>
              {paymentMethod === 'card' && (
                <div className="mt-2 bg-blue-50 text-blue-700 p-3 rounded-xl text-sm">
                  💳 Card payment will be processed at the counter separately.
                </div>
              )}
              {(paymentMethod === 'cash' || paymentMethod === 'upi') && (
                <div className="mt-2 bg-green-50 text-green-700 p-3 rounded-xl text-sm">
                  {paymentMethod === 'cash' ? '💵 Pay cash at the counter.' : '📱 Pay via UPI at the counter.'}
                </div>
              )}
            </div>

            <div className="bg-orange-50 rounded-xl p-4">
              <div className="flex justify-between font-bold text-lg">
                <span>Grand Total</span>
                <span className="text-orange-600">₹{grandTotal}</span>
              </div>
              <p className="text-xs text-gray-500 mt-1">Including 5% GST</p>
            </div>

            <button
              onClick={handlePlaceOrder}
              disabled={!customerName || !customerPhone || tableNo === 0}
              className="w-full bg-gradient-to-r from-orange-600 to-amber-500 text-white py-4 rounded-2xl font-bold text-lg hover:from-orange-700 hover:to-amber-600 transition disabled:opacity-50 disabled:cursor-not-allowed shadow-lg"
            >
              🍽️ Place Order - ₹{grandTotal}
            </button>
          </div>
        )}
      </div>
    </div>
  );
}
