import { useState } from 'react';
import { useRestaurant, MenuItem } from '../store/RestaurantContext';
import { ShoppingCart, Plus, Search, Leaf } from 'lucide-react';
import CartDrawer from './CartDrawer';

export default function CustomerMenu() {
  const { menuItems, categories, isOpen, restaurantName, getCartCount, addToCart } = useRestaurant();
  const [selectedCategory, setSelectedCategory] = useState('All');
  const [search, setSearch] = useState('');
  const [cartOpen, setCartOpen] = useState(false);
  const [showDropdown, setShowDropdown] = useState(false);

  const availableItems = menuItems.filter(i => i.available);
  const filtered = availableItems.filter(i => {
    const matchCat = selectedCategory === 'All' || i.category === selectedCategory;
    const matchSearch = i.name.toLowerCase().includes(search.toLowerCase()) || i.description.toLowerCase().includes(search.toLowerCase());
    return matchCat && matchSearch;
  });

  const cartCount = getCartCount();

  if (!isOpen) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-orange-50 to-amber-50 flex items-center justify-center p-4">
        <div className="bg-white rounded-3xl shadow-2xl p-8 max-w-md w-full text-center">
          <div className="text-6xl mb-4">🍽️</div>
          <h1 className="text-3xl font-bold text-orange-600 mb-2">{restaurantName}</h1>
          <div className="bg-red-100 text-red-700 rounded-xl p-4 mt-4">
            <p className="text-xl font-bold">🔴 Restaurant is Currently Closed</p>
            <p className="text-sm mt-2">We'll be back soon! Please check back later.</p>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-orange-50 to-amber-50">
      {/* Header */}
      <header className="bg-gradient-to-r from-orange-600 to-amber-500 text-white sticky top-0 z-40 shadow-lg">
        <div className="max-w-7xl mx-auto px-4 py-3 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 bg-white rounded-full flex items-center justify-center">
              <span className="text-orange-600 font-bold text-lg">S</span>
            </div>
            <div>
              <h1 className="text-xl font-bold">{restaurantName}</h1>
              <div className="flex items-center gap-1 text-xs">
                <span className="w-2 h-2 bg-green-400 rounded-full animate-pulse"></span>
                <span>Open Now</span>
                <span className="ml-2">⭐ 4.5</span>
              </div>
            </div>
          </div>
          <div className="flex items-center gap-3">
            {/* Hamburger menu */}
            <div className="relative">
              <button onClick={() => setShowDropdown(!showDropdown)} className="p-2 hover:bg-orange-700 rounded-lg transition">
                <div className="flex flex-col gap-1">
                  <span className="w-5 h-0.5 bg-white"></span>
                  <span className="w-5 h-0.5 bg-white"></span>
                  <span className="w-5 h-0.5 bg-white"></span>
                </div>
              </button>
              {showDropdown && (
                <div className="absolute right-0 top-12 bg-white text-gray-800 rounded-xl shadow-xl w-56 overflow-hidden z-50">
                  <a href="#menu" onClick={() => setShowDropdown(false)} className="block px-4 py-3 hover:bg-orange-50 border-b">📋 Menu</a>
                  <a href="#about" onClick={() => setShowDropdown(false)} className="block px-4 py-3 hover:bg-orange-50 border-b">ℹ️ About Us</a>
                  <a href="#contact" onClick={() => setShowDropdown(false)} className="block px-4 py-3 hover:bg-orange-50 border-b">📞 Contact</a>
                  <a href="#rating" onClick={() => setShowDropdown(false)} className="block px-4 py-3 hover:bg-orange-50">⭐ Ratings</a>
                </div>
              )}
            </div>
            {/* Cart Button */}
            <button onClick={() => setCartOpen(true)} className="relative p-2 bg-white/20 rounded-full hover:bg-white/30 transition">
              <ShoppingCart size={22} />
              {cartCount > 0 && (
                <span className="absolute -top-1 -right-1 bg-red-500 text-white text-xs w-5 h-5 flex items-center justify-center rounded-full font-bold animate-bounce">
                  {cartCount}
                </span>
              )}
            </button>
          </div>
        </div>
      </header>

      {/* Hero Banner */}
      <div className="relative h-48 md:h-64 overflow-hidden">
        <img src="https://images.unsplash.com/photo-1517248135467-4c7edcad34c4?w=1200" alt="Restaurant" className="w-full h-full object-cover" />
        <div className="absolute inset-0 bg-gradient-to-t from-black/70 to-transparent flex items-end p-6">
          <div className="text-white">
            <h2 className="text-2xl md:text-4xl font-bold">Welcome to {restaurantName}</h2>
            <p className="text-sm md:text-base opacity-90">Authentic Flavors • Premium Dining Experience</p>
          </div>
        </div>
      </div>

      {/* Rating Section */}
      <div id="rating" className="max-w-7xl mx-auto px-4 py-4">
        <div className="bg-white rounded-2xl shadow-md p-4 flex items-center justify-between flex-wrap gap-3">
          <div className="flex items-center gap-4">
            <div className="text-center">
              <div className="text-3xl font-bold text-orange-600">4.5</div>
              <div className="flex text-amber-400 text-lg">⭐⭐⭐⭐⭐</div>
              <div className="text-xs text-gray-500">1.2K+ Reviews</div>
            </div>
            <div className="h-12 w-px bg-gray-200"></div>
            <div className="text-center">
              <div className="text-2xl font-bold text-orange-600">30+</div>
              <div className="text-xs text-gray-500">Menu Items</div>
            </div>
            <div className="h-12 w-px bg-gray-200"></div>
            <div className="text-center">
              <div className="text-2xl font-bold text-orange-600">7</div>
              <div className="text-xs text-gray-500">Tables</div>
            </div>
          </div>
          <div className="bg-green-100 text-green-700 px-4 py-2 rounded-full text-sm font-semibold flex items-center gap-1">
            <span className="w-2 h-2 bg-green-500 rounded-full animate-pulse"></span> Open Now
          </div>
        </div>
      </div>

      {/* Search */}
      <div id="menu" className="max-w-7xl mx-auto px-4 pb-2">
        <div className="relative">
          <Search className="absolute left-4 top-1/2 -translate-y-1/2 text-gray-400" size={18} />
          <input
            type="text"
            placeholder="Search menu items..."
            value={search}
            onChange={e => setSearch(e.target.value)}
            className="w-full pl-11 pr-4 py-3 bg-white rounded-xl shadow-md border-0 focus:ring-2 focus:ring-orange-400 outline-none text-sm"
          />
        </div>
      </div>

      {/* Categories */}
      <div className="max-w-7xl mx-auto px-4 py-3">
        <div className="flex gap-2 overflow-x-auto pb-2 scrollbar-hide">
          <button
            onClick={() => setSelectedCategory('All')}
            className={`px-4 py-2 rounded-full text-sm font-semibold whitespace-nowrap transition ${selectedCategory === 'All' ? 'bg-orange-600 text-white shadow-lg' : 'bg-white text-gray-600 hover:bg-orange-100'}`}
          >
            🍽️ All
          </button>
          {categories.map(cat => (
            <button
              key={cat}
              onClick={() => setSelectedCategory(cat)}
              className={`px-4 py-2 rounded-full text-sm font-semibold whitespace-nowrap transition ${selectedCategory === cat ? 'bg-orange-600 text-white shadow-lg' : 'bg-white text-gray-600 hover:bg-orange-100'}`}
            >
              {cat}
            </button>
          ))}
        </div>
      </div>

      {/* Menu Items Grid */}
      <div className="max-w-7xl mx-auto px-4 pb-32">
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
          {filtered.map(item => (
            <MenuCard key={item.id} item={item} onAdd={() => addToCart(item)} />
          ))}
        </div>
        {filtered.length === 0 && (
          <div className="text-center py-12 text-gray-400">
            <p className="text-5xl mb-4">🍽️</p>
            <p className="text-lg">No items found</p>
          </div>
        )}
      </div>

      {/* About Section */}
      <div id="about" className="bg-gradient-to-r from-orange-600 to-amber-500 text-white py-12 px-4">
        <div className="max-w-4xl mx-auto text-center">
          <h2 className="text-3xl font-bold mb-4">About {restaurantName}</h2>
          <p className="text-lg opacity-90 mb-6">We serve the finest authentic cuisine with love and passion. Our chefs use only the freshest ingredients to create dishes that delight your taste buds.</p>
          <div className="grid grid-cols-3 gap-4">
            <div className="bg-white/20 rounded-xl p-4">
              <div className="text-3xl mb-2">👨‍🍳</div>
              <div className="font-bold">Expert Chefs</div>
            </div>
            <div className="bg-white/20 rounded-xl p-4">
              <div className="text-3xl mb-2">🥗</div>
              <div className="font-bold">Fresh Ingredients</div>
            </div>
            <div className="bg-white/20 rounded-xl p-4">
              <div className="text-3xl mb-2">❤️</div>
              <div className="font-bold">Made with Love</div>
            </div>
          </div>
        </div>
      </div>

      {/* Contact Section */}
      <div id="contact" className="bg-gray-900 text-white py-8 px-4">
        <div className="max-w-4xl mx-auto text-center">
          <h3 className="text-xl font-bold mb-4">Contact Us</h3>
          <p className="opacity-70">© 2025 {restaurantName}. All rights reserved.</p>
          <p className="opacity-70 text-sm mt-1">Powered by SIXTIN</p>
        </div>
      </div>

      {/* Floating Cart Button (Mobile) */}
      {cartCount > 0 && (
        <div className="fixed bottom-4 left-4 right-4 z-40 md:hidden">
          <button
            onClick={() => setCartOpen(true)}
            className="w-full bg-orange-600 text-white py-4 rounded-2xl shadow-2xl flex items-center justify-between px-6 hover:bg-orange-700 transition"
          >
            <div className="flex items-center gap-2">
              <ShoppingCart size={20} />
              <span className="font-bold">{cartCount} items</span>
            </div>
            <span className="font-bold">View Cart →</span>
          </button>
        </div>
      )}

      {/* Cart Drawer */}
      <CartDrawer open={cartOpen} onClose={() => setCartOpen(false)} />
    </div>
  );
}

function MenuCard({ item, onAdd }: { item: MenuItem; onAdd: () => void }) {
  return (
    <div className="bg-white rounded-2xl shadow-md overflow-hidden hover:shadow-xl transition group">
      <div className="relative h-44 overflow-hidden">
        <img
          src={item.image}
          alt={item.name}
          className="w-full h-full object-cover group-hover:scale-110 transition duration-500"
          onError={(e) => { (e.target as HTMLImageElement).src = 'https://images.unsplash.com/photo-1546069901-ba9599a7e63c?w=600'; }}
        />
        <div className="absolute top-3 left-3">
          {item.veg ? (
            <span className="bg-green-500 text-white text-xs px-2 py-1 rounded-full flex items-center gap-1"><Leaf size={12} /> Veg</span>
          ) : (
            <span className="bg-red-500 text-white text-xs px-2 py-1 rounded-full">Non-Veg</span>
          )}
        </div>
        <div className="absolute top-3 right-3 bg-orange-600 text-white px-3 py-1 rounded-full text-sm font-bold">
          ₹{item.price}
        </div>
      </div>
      <div className="p-4">
        <h3 className="font-bold text-gray-800 text-lg">{item.name}</h3>
        <p className="text-gray-500 text-sm mt-1 line-clamp-2">{item.description}</p>
        <div className="flex items-center justify-between mt-3">
          <span className="text-xs text-orange-500 bg-orange-50 px-2 py-1 rounded-full">{item.category}</span>
          <button
            onClick={onAdd}
            className="bg-orange-600 hover:bg-orange-700 text-white px-4 py-2 rounded-xl text-sm font-semibold flex items-center gap-1 transition active:scale-95"
          >
            <Plus size={16} /> ADD
          </button>
        </div>
      </div>
    </div>
  );
}
