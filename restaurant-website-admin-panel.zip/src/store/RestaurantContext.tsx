import { createContext, useContext, useState, useEffect, ReactNode } from 'react';

export interface MenuItem {
  id: string;
  name: string;
  nameHi?: string;
  price: number;
  category: string;
  image: string;
  description: string;
  available: boolean;
  veg: boolean;
}

export interface OrderItem {
  item: MenuItem;
  quantity: number;
}

export interface Order {
  orderId: number;
  items: OrderItem[];
  tableNo: number;
  customerName: string;
  customerPhone: string;
  total: number;
  paymentMethod: 'cash' | 'upi' | 'card';
  status: 'pending' | 'confirmed' | 'preparing' | 'ready' | 'delivered' | 'cancelled';
  paymentStatus: 'pending' | 'paid';
  estimatedTime?: number;
  createdAt: string;
}

export interface StaffMember {
  id: string;
  name: string;
  role: string;
  phone: string;
  active: boolean;
}

interface RestaurantState {
  restaurantName: string;
  isOpen: boolean;
  menuItems: MenuItem[];
  orders: Order[];
  staff: StaffMember[];
  cart: OrderItem[];
  nextOrderId: number;
  tables: { no: number; occupied: boolean }[];
  whatsappNumber: string;
  categories: string[];
}

interface RestaurantContextType extends RestaurantState {
  setRestaurantName: (name: string) => void;
  toggleOpen: () => void;
  setIsOpen: (open: boolean) => void;
  addMenuItem: (item: MenuItem) => void;
  updateMenuItem: (id: string, item: Partial<MenuItem>) => void;
  removeMenuItem: (id: string) => void;
  toggleItemAvailability: (id: string) => void;
  addToCart: (item: MenuItem) => void;
  removeFromCart: (itemId: string) => void;
  updateCartQuantity: (itemId: string, qty: number) => void;
  clearCart: () => void;
  placeOrder: (customerName: string, customerPhone: string, tableNo: number, paymentMethod: 'cash' | 'upi' | 'card') => Order | null;
  updateOrderStatus: (orderId: number, status: Order['status']) => void;
  updatePaymentStatus: (orderId: number, status: Order['paymentStatus']) => void;
  setEstimatedTime: (orderId: number, time: number) => void;
  addStaff: (staff: StaffMember) => void;
  removeStaff: (id: string) => void;
  toggleStaffActive: (id: string) => void;
  toggleTableOccupied: (no: number) => void;
  setWhatsappNumber: (num: string) => void;
  addCategory: (cat: string) => void;
  removeCategory: (cat: string) => void;
  getCartTotal: () => number;
  getCartCount: () => number;
}

const defaultMenu: MenuItem[] = [
  { id: '1', name: 'Butter Chicken', price: 320, category: 'Main Course', image: 'https://images.unsplash.com/photo-1603894584373-5ac82b2ae398?w=600', description: 'Creamy tomato-based chicken curry with butter and spices', available: true, veg: false },
  { id: '2', name: 'Paneer Tikka', price: 250, category: 'Starters', image: 'https://images.unsplash.com/photo-1567188040759-fb8a883dc6d8?w=600', description: 'Grilled cottage cheese marinated in spicy yogurt', available: true, veg: true },
  { id: '3', name: 'Biryani', price: 280, category: 'Main Course', image: 'https://images.unsplash.com/photo-1563379091339-03b21ab4a4f8?w=600', description: 'Fragrant basmati rice cooked with aromatic spices and herbs', available: true, veg: false },
  { id: '4', name: 'Dal Makhani', price: 220, category: 'Main Course', image: 'https://images.unsplash.com/photo-1546833999-b9f581a1996d?w=600', description: 'Creamy black lentil curry simmered overnight', available: true, veg: true },
  { id: '5', name: 'Tandoori Chicken', price: 350, category: 'Starters', image: 'https://images.unsplash.com/photo-1599487488170-d11ec9c172f0?w=600', description: 'Chicken marinated in yogurt and spices, cooked in tandoor', available: true, veg: false },
  { id: '6', name: 'Naan', price: 50, category: 'Breads', image: 'https://images.unsplash.com/photo-1565557623262-b51c2513a641?w=600', description: 'Soft leavened bread baked in tandoor', available: true, veg: true },
  { id: '7', name: 'Gulab Jamun', price: 120, category: 'Desserts', image: 'https://images.unsplash.com/photo-1666190077553-a65511abb830?w=600', description: 'Deep-fried milk dumplings soaked in sugar syrup', available: true, veg: true },
  { id: '8', name: 'Mango Lassi', price: 100, category: 'Beverages', image: 'https://images.unsplash.com/photo-1527661591475-527312dd65f5?w=600', description: 'Refreshing yogurt-based mango smoothie', available: true, veg: true },
  { id: '9', name: 'Samosa', price: 60, category: 'Starters', image: 'https://images.unsplash.com/photo-1601050690597-df0568f70950?w=600', description: 'Crispy pastry filled with spiced potatoes and peas', available: true, veg: true },
  { id: '10', name: 'Chicken Tikka Masala', price: 300, category: 'Main Course', image: 'https://images.unsplash.com/photo-1565557623262-b51c2513a641?w=600', description: 'Grilled chicken chunks in rich creamy masala gravy', available: true, veg: false },
  { id: '11', name: 'Masala Chai', price: 40, category: 'Beverages', image: 'https://images.unsplash.com/photo-1556679343-c7306c1976bc?w=600', description: 'Traditional Indian spiced tea', available: true, veg: true },
  { id: '12', name: 'Raita', price: 70, category: 'Sides', image: 'https://images.unsplash.com/photo-1631452180519-c014fe946bc7?w=600', description: 'Cooling yogurt with cucumber and spices', available: true, veg: true },
];

const defaultCategories = ['Starters', 'Main Course', 'Breads', 'Sides', 'Desserts', 'Beverages'];

const defaultTables = Array.from({ length: 7 }, (_, i) => ({ no: i + 1, occupied: false }));

const STORAGE_KEY = 'sixtin_restaurant_data';

function loadState(): Partial<RestaurantState> {
  try {
    const saved = localStorage.getItem(STORAGE_KEY);
    if (saved) return JSON.parse(saved);
  } catch { }
  return {};
}

function saveState(state: RestaurantState) {
  try {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(state));
  } catch { }
}

const RestaurantContext = createContext<RestaurantContextType | null>(null);

export function RestaurantProvider({ children }: { children: ReactNode }) {
  const saved = loadState();
  const [restaurantName, setRestaurantName] = useState(saved.restaurantName || 'SIXTIN Restaurant');
  const [isOpen, setIsOpen] = useState(saved.isOpen ?? true);
  const [menuItems, setMenuItems] = useState<MenuItem[]>(saved.menuItems || defaultMenu);
  const [orders, setOrders] = useState<Order[]>(saved.orders || []);
  const [staff, setStaff] = useState<StaffMember[]>(saved.staff || []);
  const [cart, setCart] = useState<OrderItem[]>([]);
  const [nextOrderId, setNextOrderId] = useState(saved.nextOrderId || 1001);
  const [tables, setTables] = useState(saved.tables || defaultTables);
  const [whatsappNumber, setWhatsappNumber] = useState(saved.whatsappNumber || '919999999999');
  const [categories, setCategories] = useState<string[]>(saved.categories || defaultCategories);

  useEffect(() => {
    saveState({ restaurantName, isOpen, menuItems, orders, staff, cart: [], nextOrderId, tables, whatsappNumber, categories });
  }, [restaurantName, isOpen, menuItems, orders, staff, nextOrderId, tables, whatsappNumber, categories]);

  const toggleOpen = () => setIsOpen(p => !p);

  const addMenuItem = (item: MenuItem) => setMenuItems(p => [...p, item]);
  const updateMenuItem = (id: string, updates: Partial<MenuItem>) => setMenuItems(p => p.map(i => i.id === id ? { ...i, ...updates } : i));
  const removeMenuItem = (id: string) => setMenuItems(p => p.filter(i => i.id !== id));
  const toggleItemAvailability = (id: string) => setMenuItems(p => p.map(i => i.id === id ? { ...i, available: !i.available } : i));

  const addToCart = (item: MenuItem) => {
    setCart(p => {
      const existing = p.find(c => c.item.id === item.id);
      if (existing) return p.map(c => c.item.id === item.id ? { ...c, quantity: c.quantity + 1 } : c);
      return [...p, { item, quantity: 1 }];
    });
  };
  const removeFromCart = (itemId: string) => setCart(p => p.filter(c => c.item.id !== itemId));
  const updateCartQuantity = (itemId: string, qty: number) => {
    if (qty <= 0) return removeFromCart(itemId);
    setCart(p => p.map(c => c.item.id === itemId ? { ...c, quantity: qty } : c));
  };
  const clearCart = () => setCart([]);
  const getCartTotal = () => cart.reduce((sum, c) => sum + c.item.price * c.quantity, 0);
  const getCartCount = () => cart.reduce((sum, c) => sum + c.quantity, 0);

  const placeOrder = (customerName: string, customerPhone: string, tableNo: number, paymentMethod: 'cash' | 'upi' | 'card') => {
    if (cart.length === 0) return null;
    const order: Order = {
      orderId: nextOrderId,
      items: [...cart],
      tableNo,
      customerName,
      customerPhone,
      total: getCartTotal(),
      paymentMethod,
      status: 'pending',
      paymentStatus: 'pending',
      createdAt: new Date().toISOString(),
    };
    setOrders(p => [order, ...p]);
    setNextOrderId(p => p + 1);
    clearCart();

    // Send WhatsApp message
    const itemsList = order.items.map(i => `${i.item.name} x${i.quantity} = ₹${i.item.price * i.quantity}`).join('%0A');
    const msg = `🍽️ *New Order #${order.orderId}*%0A%0A👤 Customer: ${customerName}%0A📱 Phone: ${customerPhone}%0A🪑 Table: ${tableNo}%0A%0A📋 *Items:*%0A${itemsList}%0A%0A💰 *Total: ₹${order.total}*%0A💳 Payment: ${paymentMethod.toUpperCase()}%0A⏰ ${new Date().toLocaleTimeString()}`;
    window.open(`https://wa.me/${whatsappNumber}?text=${msg}`, '_blank');

    return order;
  };

  const updateOrderStatus = (orderId: number, status: Order['status']) => setOrders(p => p.map(o => o.orderId === orderId ? { ...o, status } : o));
  const updatePaymentStatus = (orderId: number, status: Order['paymentStatus']) => setOrders(p => p.map(o => o.orderId === orderId ? { ...o, paymentStatus: status } : o));
  const setEstimatedTime = (orderId: number, time: number) => setOrders(p => p.map(o => o.orderId === orderId ? { ...o, estimatedTime: time } : o));

  const addStaff = (s: StaffMember) => setStaff(p => [...p, s]);
  const removeStaff = (id: string) => setStaff(p => p.filter(s => s.id !== id));
  const toggleStaffActive = (id: string) => setStaff(p => p.map(s => s.id === id ? { ...s, active: !s.active } : s));

  const toggleTableOccupied = (no: number) => setTables(p => p.map(t => t.no === no ? { ...t, occupied: !t.occupied } : t));

  const addCategory = (cat: string) => setCategories(p => p.includes(cat) ? p : [...p, cat]);
  const removeCategory = (cat: string) => setCategories(p => p.filter(c => c !== cat));

  return (
    <RestaurantContext.Provider value={{
      restaurantName, isOpen, menuItems, orders, staff, cart, nextOrderId, tables, whatsappNumber, categories,
      setRestaurantName, toggleOpen, setIsOpen, addMenuItem, updateMenuItem, removeMenuItem, toggleItemAvailability,
      addToCart, removeFromCart, updateCartQuantity, clearCart, placeOrder, updateOrderStatus, updatePaymentStatus,
      setEstimatedTime, addStaff, removeStaff, toggleStaffActive, toggleTableOccupied, setWhatsappNumber,
      addCategory, removeCategory, getCartTotal, getCartCount,
    }}>
      {children}
    </RestaurantContext.Provider>
  );
}

export function useRestaurant() {
  const ctx = useContext(RestaurantContext);
  if (!ctx) throw new Error('useRestaurant must be used within RestaurantProvider');
  return ctx;
}
