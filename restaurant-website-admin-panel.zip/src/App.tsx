import { useState, useEffect } from 'react';
import { RestaurantProvider } from './store/RestaurantContext';
import CustomerMenu from './components/CustomerMenu';
import AdminLogin from './components/AdminLogin';
import AdminDashboard from './components/AdminDashboard';

type Page = 'customer' | 'admin-login' | 'admin-dashboard';

function AppContent() {
  const [page, setPage] = useState<Page>('customer');
  const [isLoggedIn, setIsLoggedIn] = useState(false);

  useEffect(() => {
    // Check hash for routing
    const handleHash = () => {
      const hash = window.location.hash;
      if (hash === '#/admin') {
        if (isLoggedIn) {
          setPage('admin-dashboard');
        } else {
          setPage('admin-login');
        }
      } else {
        setPage('customer');
      }
    };

    handleHash();
    window.addEventListener('hashchange', handleHash);
    return () => window.removeEventListener('hashchange', handleHash);
  }, [isLoggedIn]);

  const handleLogin = () => {
    setIsLoggedIn(true);
    setPage('admin-dashboard');
  };

  const handleLogout = () => {
    setIsLoggedIn(false);
    window.location.hash = '#/';
  };

  return (
    <>
      {page === 'customer' && <CustomerMenu />}
      {page === 'admin-login' && <AdminLogin onLogin={handleLogin} />}
      {page === 'admin-dashboard' && <AdminDashboard onLogout={handleLogout} />}
    </>
  );
}

export default function App() {
  return (
    <RestaurantProvider>
      <AppContent />
    </RestaurantProvider>
  );
}
